
# cloudinary-cli (via pipx) (cloudinary-cli)

Cloudinary CLI.

## Example DevContainer Usage

```json
"features": {
    "ghcr.io/devcontainers-contrib/features/cloudinary-cli:1": {}
}
```

## Options

| Options Id | Description | Type | Default Value |
|-----|-----|-----|-----|
| version | Select the version of cloudinary-cli to install. | string | latest |


