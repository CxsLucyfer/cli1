
# cloud-nuke (via Github Releases) (cloud-nuke)

cloud-nuke is a tool for cleaning up your cloud accounts by nuking (deleting) all resources within it

## Example DevContainer Usage

```json
"features": {
    "ghcr.io/devcontainers-contrib/features/cloud-nuke:1": {}
}
```

## Options

| Options Id | Description | Type | Default Value |
|-----|-----|-----|-----|
| version | Select the version to install. | string | latest |


