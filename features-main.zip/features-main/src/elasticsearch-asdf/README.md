
# Elasticsearch (via asdf) (elasticsearch-asdf)

Elasticsearch is a search engine based on the Lucene library.

## Example DevContainer Usage

```json
"features": {
    "ghcr.io/devcontainers-contrib/features/elasticsearch-asdf:2": {}
}
```

## Options

| Options Id | Description | Type | Default Value |
|-----|-----|-----|-----|
| version | Select the version to install. | string | latest |


