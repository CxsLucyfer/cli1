
# Dashlane CLI (via Github Releases) (dashlane-cli)

Dashlane Command Line Interface allows you to get your passwords, otp and secure notes right from your terminal.

## Example DevContainer Usage

```json
"features": {
    "ghcr.io/devcontainers-contrib/features/dashlane-cli:1": {}
}
```

## Options

| Options Id | Description | Type | Default Value |
|-----|-----|-----|-----|
| version | Select the version to install. | string | latest |


