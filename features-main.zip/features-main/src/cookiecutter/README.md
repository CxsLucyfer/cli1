
# Cookiecutter (via pipx) (cookiecutter)

Cookiecutter creates projects from project templates.

## Example DevContainer Usage

```json
"features": {
    "ghcr.io/devcontainers-contrib/features/cookiecutter:2": {}
}
```

## Options

| Options Id | Description | Type | Default Value |
|-----|-----|-----|-----|
| version | Select the version to install. | string | latest |


