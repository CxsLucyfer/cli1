
# exa (via Github Releases) (exa)

exa is a modern replacement for ls.

## Example DevContainer Usage

```json
"features": {
    "ghcr.io/devcontainers-contrib/features/exa:1": {}
}
```

## Options

| Options Id | Description | Type | Default Value |
|-----|-----|-----|-----|
| version | Select the version to install. | string | latest |


