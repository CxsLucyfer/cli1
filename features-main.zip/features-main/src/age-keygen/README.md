
# age-keygen (via Github Releases) (age-keygen)

age-keygen generate a key pair for use with age.

## Example DevContainer Usage

```json
"features": {
    "ghcr.io/devcontainers-contrib/features/age-keygen:1": {}
}
```

## Options

| Options Id | Description | Type | Default Value |
|-----|-----|-----|-----|
| version | Select the version to install. | string | latest |


