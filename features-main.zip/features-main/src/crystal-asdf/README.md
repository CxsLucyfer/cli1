
# Crystal (via asdf) (crystal-asdf)

Crystal is a general-purpose, object-oriented programming language

## Example DevContainer Usage

```json
"features": {
    "ghcr.io/devcontainers-contrib/features/crystal-asdf:2": {}
}
```

## Options

| Options Id | Description | Type | Default Value |
|-----|-----|-----|-----|
| version | Select the version to install. | string | latest |


