
# buku (via pipx) (buku)

buku is a powerful bookmark manager and a personal textual mini-web.

## Example DevContainer Usage

```json
"features": {
    "ghcr.io/devcontainers-contrib/features/buku:1": {}
}
```

## Options

| Options Id | Description | Type | Default Value |
|-----|-----|-----|-----|
| version | Select the version to install. | string | latest |


