
# cURL (via apt-get) (curl-apt-get)

cURL is a computer software project providing a library and command-line tool for transferring data using various network protocols.

## Example DevContainer Usage

```json
"features": {
    "ghcr.io/devcontainers-contrib/features/curl-apt-get:1": {}
}
```



