
# chezscheme (via asdf) (chezscheme-asdf)

Chez Scheme is both a programming language and an implementation of that language, with supporting tools and documentation.

## Example DevContainer Usage

```json
"features": {
    "ghcr.io/devcontainers-contrib/features/chezscheme-asdf:2": {}
}
```

## Options

| Options Id | Description | Type | Default Value |
|-----|-----|-----|-----|
| version | Select the version to install. | string | latest |


