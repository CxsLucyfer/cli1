
# ddgr (via Homebrew) (ddgr-homebrew)

ddgr is a cmdline utility to search DuckDuckGo from the terminal.

## Example DevContainer Usage

```json
"features": {
    "ghcr.io/devcontainers-contrib/features/ddgr-homebrew:1": {}
}
```

## Options

| Options Id | Description | Type | Default Value |
|-----|-----|-----|-----|
| version | Select the version to install. | string | latest |


