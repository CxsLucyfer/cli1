
# apko (via Github Releases) (apko)

apko is an apk-based OCI image builder

## Example DevContainer Usage

```json
"features": {
    "ghcr.io/devcontainers-contrib/features/apko:1": {}
}
```

## Options

| Options Id | Description | Type | Default Value |
|-----|-----|-----|-----|
| version | Select the version to install. | string | latest |


