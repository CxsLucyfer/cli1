
# boundary (via asdf) (boundary-asdf)

Installs boundary

## Example DevContainer Usage

```json
"features": {
    "ghcr.io/devcontainers-contrib/features/boundary-asdf:2": {}
}
```

## Options

| Options Id | Description | Type | Default Value |
|-----|-----|-----|-----|
| version | Select the version to install. | string | latest |


