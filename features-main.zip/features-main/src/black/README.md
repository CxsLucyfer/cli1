
# Black (via pipx) (black)

Black is an uncompromising Python code formatter.

## Example DevContainer Usage

```json
"features": {
    "ghcr.io/devcontainers-contrib/features/black:2": {}
}
```

## Options

| Options Id | Description | Type | Default Value |
|-----|-----|-----|-----|
| version | Select the version to install. | string | latest |


