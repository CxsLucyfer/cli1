
# bomber (via Github Releases) (bomber)

bomber is an application that scans SBOMs for security vulnerabilities.

## Example DevContainer Usage

```json
"features": {
    "ghcr.io/devcontainers-contrib/features/bomber:1": {}
}
```

## Options

| Options Id | Description | Type | Default Value |
|-----|-----|-----|-----|
| version | Select the version to install. | string | latest |


