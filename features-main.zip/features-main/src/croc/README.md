
# croc (via Github Releases) (croc)

croc is a tool that allows any two computers to simply and securely transfer files and folders.

## Example DevContainer Usage

```json
"features": {
    "ghcr.io/devcontainers-contrib/features/croc:1": {}
}
```

## Options

| Options Id | Description | Type | Default Value |
|-----|-----|-----|-----|
| version | Select the version to install. | string | latest |


