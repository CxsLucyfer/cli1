
# dprint (via asdf) (dprint-asdf)

dprint is a pluggable and configurable code formatting platform written in Rust.

## Example DevContainer Usage

```json
"features": {
    "ghcr.io/devcontainers-contrib/features/dprint-asdf:2": {}
}
```

## Options

| Options Id | Description | Type | Default Value |
|-----|-----|-----|-----|
| version | Select the version to install. | string | latest |


