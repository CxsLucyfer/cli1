
# ddgr (via apt-get) (ddgr-apt-get)

ddgr is a cmdline utility to search DuckDuckGo from the terminal.

## Example DevContainer Usage

```json
"features": {
    "ghcr.io/devcontainers-contrib/features/ddgr-apt-get:1": {}
}
```



