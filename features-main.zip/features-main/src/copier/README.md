
# copier (via pipx) (copier)

copier creates projects from project templates.

## Example DevContainer Usage

```json
"features": {
    "ghcr.io/devcontainers-contrib/features/copier:7": {}
}
```

## Options

| Options Id | Description | Type | Default Value |
|-----|-----|-----|-----|
| version | Select the version to install. | string | latest |


