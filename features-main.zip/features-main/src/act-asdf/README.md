
# act (via asdf) (act-asdf)

Act is an open source project that allows you to run your github flow locally.

## Example DevContainer Usage

```json
"features": {
    "ghcr.io/devcontainers-contrib/features/act-asdf:2": {}
}
```

## Options

| Options Id | Description | Type | Default Value |
|-----|-----|-----|-----|
| version | Select the version to install. | string | latest |


