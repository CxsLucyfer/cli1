
# Bandit (via pipx) (bandit)

Bandit is a tool designed to find common security issues in Python code.

## Example DevContainer Usage

```json
"features": {
    "ghcr.io/devcontainers-contrib/features/bandit:2": {}
}
```

## Options

| Options Id | Description | Type | Default Value |
|-----|-----|-----|-----|
| version | Select the version to install. | string | latest |


